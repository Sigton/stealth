Sound file samples used by Lib/test/test_sndhdr.py and generated using the
following commands:

   dd if=/dev/zero of=sndhdr.raw bs=20 count=1
   sox -s -2 -c 2 -r 44100 sndhdr.raw sndhdr.<format>

Sound file samples used by Lib/test/test_sndhdr.py and generated using the
following commands:

   dd if=/dev/zero of=sndhdr.raw bs=20 count=1
   sox -s -2 -c 2 -r 44100 sndhdr.raw sndhdr.<format>

